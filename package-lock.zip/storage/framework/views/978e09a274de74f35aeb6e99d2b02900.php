<?php $__env->startSection('title', 'Salarios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Tabla de Salarios
                    </h2>
                    <div class="panel-toolbar">
                        <button type="button" class="btn btn-info active" onclick="showModalRegistro('Salario', true);">
                            Agregar <i class="fal fa-plus-square"></i>
                        </button>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.DataTable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DataTable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <th>ID</th>
                    <th>Descripción</th>
                    <th>Monto</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $attributes = $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $component = $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    <?php if (isset($component)) { $__componentOriginale58da52603d8728ca37800fd8b40881d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale58da52603d8728ca37800fd8b40881d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ModalForm','data' => ['title' => 'Agregar Salario','description' => 'Los salarios son deacuerdo a la nomina del usuario.','form' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ModalForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar Salario','description' => 'Los salarios son deacuerdo a la nomina del usuario.','form' => true]); ?>
        <div class="form-row">
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'description','type' => 'text','label' => 'Descripción','placeholder' => 'Ingresa descripcion de la nomina','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'description','type' => 'text','label' => 'Descripción','placeholder' => 'Ingresa descripcion de la nomina','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'amount','type' => 'number','label' => 'Salario','placeholder' => 'Ingrese cantidad del salario','required' => true,'max' => '1000000']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'amount','type' => 'number','label' => 'Salario','placeholder' => 'Ingrese cantidad del salario','required' => true,'max' => '1000000']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $attributes = $__attributesOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__attributesOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $component = $__componentOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__componentOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(async () => {
            await buildDataTable("salarios",
                [{
                        data: 'id',
                    },
                    {
                        data: 'description',
                    },
                    {
                        data: 'amount',
                    },
                    {
                        data: 'status',
                    },
                    {
                        data: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]);
        });

        const crearRegistro = async (form) => {
            await buildCreateRegister("api/salarios", form);
        };

        const editarRegistro = async (nit) => {
            await buildEditRegister(nit, "api/salarios",
                [
                    "id",
                    "description",
                    "amount",
                ], true);
        }

        const statusRegistro = async (nit) => {
            await buildStatusRegister(nit, "api/salarios");
        };

        const eliminarRegistro = async (nit) => {
            await buildDeleteRegister(nit, "api/salarios");
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/cuentas/salarios/salarios.blade.php ENDPATH**/ ?>