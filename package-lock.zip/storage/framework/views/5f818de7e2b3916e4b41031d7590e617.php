<div class="modal fade" id="<?php echo e($modalId); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">
                    <?php echo e($title); ?>

                    <small class="m-0 text-muted">
                        <?php echo e($description); ?>

                    </small>
                </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fal fa-times"></i></span>
                </button>
            </div>
            <div class="modal-body">
                <form id="frmRegistro">
                    <?php echo e($slot); ?>

                </form>
            </div>
            <?php if(isset($form)): ?>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" id="btnRegistroDescontable">Agregar</button>
            </div>
        <?php else: ?>
            <div class="modal-footer">
                <button type="button" class="btn btn-info" data-dismiss="modal">cerrar</button>
            </div>
        <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/components/ModalDetailForm.blade.php ENDPATH**/ ?>