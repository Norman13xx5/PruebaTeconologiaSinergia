<?php if(isset($login) && $login): ?>
    <div class="form-group">
        <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <input type="<?php echo e($type); ?>" onKeyPress="if(this.value.length==<?php echo e($max); ?>)return false;"
            min="0" class="form-control form-control-lg" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            placeholder="<?php echo e($placeholder); ?>" <?php echo e($required ? 'required' : ''); ?>>
        <div class="invalid-feedback"><?php echo e($error ? $error : ''); ?></div>
        <div class="help-block"><?php echo e($help ? $help : ''); ?></div>
    </div>
<?php elseif(isset($textarea) && $textarea): ?>
    <div class="col-md-<?php echo e($col); ?> mb-3">
        <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <textarea onKeyPress="if(this.value.length==1000)return false;" class="form-control" id="<?php echo e($name); ?>"
            name="<?php echo e($name); ?>" rows="5" style="height: 77px;" <?php echo e($required ? 'required' : ''); ?>></textarea>
    </div>
<?php elseif(isset($file) && $file): ?>
    <div class="col-md-12" id="archivoBase64"></div>
    <label class="form-label" for="archivo"><?php echo e($title); ?></label>
    <div class="input-group">
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="archivo" name="archivo" accept="<?php echo e($accept); ?>"
                required>
            <label class="custom-file-label" for=archivo"><?php echo e($label); ?></label>
        </div>
    </div>
    <span class="help-block"><?php echo e($span); ?></span>
<?php else: ?>
    <div class="col-md-<?php echo e($col); ?> mb-3">
        <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <input type="<?php echo e($type); ?>" onKeyPress="if(this.value.length==<?php echo e($max); ?>)return false;"
            class="form-control" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            placeholder="<?php echo e($placeholder); ?>" <?php echo e($required ? 'required' : ''); ?>>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/components/InputBase.blade.php ENDPATH**/ ?>