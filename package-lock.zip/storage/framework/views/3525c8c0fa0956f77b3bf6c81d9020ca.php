<?php $__env->startSection('title', 'Formulario de Permisos'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Formulario de Permisos al rol <?php echo e($rol); ?> con id <?php echo e($id); ?>

                    </h2>
                    <div class="panel-toolbar">
                        <a class="btn btn-info mr-1" href="<?php echo e(route('roles')); ?>">
                            <i class="fal fa-arrow-left"></i>
                            Regresar
                        </a>
                        <button class="btn btn-primary ml-1" type="button" onclick="guardarPermisos('frmPermisos');">
                            Guardar Permisos
                            <i class="fal fa-save"></i>
                        </button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <form id="frmPermisos" class="text-center">
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'roles']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'roles']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'empresas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'empresas']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'usuarios']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'usuarios']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'acuerdos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'acuerdos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'contratos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'contratos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'maquinarias']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'maquinarias']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'materiales']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'materiales']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'rutas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'rutas']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'registros']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'registros']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.Permisos','data' => ['page' => 'informes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Permisos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'informes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $attributes = $__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__attributesOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994)): ?>
<?php $component = $__componentOriginalc220343e34bcfd4d3c9a55a08ad67994; ?>
<?php unset($__componentOriginalc220343e34bcfd4d3c9a55a08ad67994); ?>
<?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const guardarPermisos = async (form) => {
            const formData = new FormData(document.getElementById(form));
            formData.append("_method", "PUT");

            for (const [key, value] of formData.entries()) {
                console.log(`${key}: ${value}`);
            }
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/cuentas/roles/permisos.blade.php ENDPATH**/ ?>