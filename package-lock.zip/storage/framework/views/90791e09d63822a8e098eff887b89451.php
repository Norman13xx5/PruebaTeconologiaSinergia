<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Tabla de Usuarios
                    </h2>
                    <div class="panel-toolbar">
                        <button type="button" class="btn btn-info active" onclick="showModalRegistro('Usuario', true);">
                            Agregar <i class="fal fa-plus-square"></i>
                        </button>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.DataTable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DataTable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <th>Id</th>
                    <th>Identificación</th>
                    <th>Nombres</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Telefono</th>
                    <th>Correo Electronico</th>
                    <th>Nombre Fiscal</th>
                    <th>Dirección Fiscal</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $attributes = $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $component = $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    <?php if (isset($component)) { $__componentOriginale58da52603d8728ca37800fd8b40881d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale58da52603d8728ca37800fd8b40881d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ModalForm','data' => ['title' => 'Agregar Usuario','description' => 'Los usuarios dependen de una empresa directatente y segun su rol pertenecen a una sucursal o no.','form' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ModalForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar Usuario','description' => 'Los usuarios dependen de una empresa directatente y segun su rol pertenecen a una sucursal o no.','form' => true]); ?>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="identificacion">Identificacion</label>
                <input type="number" onKeyPress="if(this.value.length==50)return false;" min="0"
                    class="form-control" id="identificacion" name="identificacion" placeholder="Identificación del usuario"
                    required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="nombres">Nombres</label>
                <div class="input-group">
                    <input type="text" onKeyPress="if(this.value.length==50)return false;" min="0"
                        class="form-control" id="nombres" name="nombres" placeholder="Nombres del usuario" required>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="aPaterno">Apellido Paterno</label>
                <input type="text" onKeyPress="if(this.value.length==30)return false;" min="0"
                    class="form-control" id="aPaterno" name="aPaterno" placeholder="Apellido Paterno" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="aMaterno">Apellido Materno</label>
                <input type="text" onKeyPress="if(this.value.length==30)return false;" min="0"
                    class="form-control" id="aMaterno" name="aMaterno" placeholder="Apellido Materno" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="telefono">Telefono</label>
                <input type="number" onKeyPress="if(this.value.length==10)return false;" min="0"
                    class="form-control" id="telefono" name="telefono" placeholder="Telefono" required>
            </div>
        </div>

        <div class="form-row">
            <div class="col-md-8 mb-3">
                <label class="form-label" for="emailUser">Correo Electronico</label>
                <input type="email" onKeyPress="if(this.value.length==100)return false;" min="0"
                    class="form-control" id="emailUser" name="emailUser" placeholder="Correo Electronico del usuario"
                    required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="pswd">Contraseña</label>
                <input type="text" onKeyPress="if(this.value.length==20)return false;" min="0"
                    class="form-control" id="pswd" name="pswd" placeholder="Contraseña" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="nombreFiscal">Nombre Fiscal</label>
                <input type="text" onKeyPress="if(this.value.length==81)return false;" min="0"
                    class="form-control" id="nombreFiscal" name="nombreFiscal" placeholder="Nombre fiscal del usuario"
                    required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label" for="direccionFiscal">Dirección Fiscal</label>
                <input type="text" onKeyPress="if(this.value.length==100)return false;" min="0"
                    class="form-control" id="direccionFiscal" name="direccionFiscal"
                    placeholder="Dirección fiscal del usuario" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Rol Usuario</label>
                <select class="custom-select form-control" id="rolId" name="rolId">
                </select>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['file' => true,'title' => 'Foto de Usuario','label' => 'Adjuntar Foto del Usuario','accept' => 'image/png','span' => 'Foto del usuario en formato png.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['file' => true,'title' => 'Foto de Usuario','label' => 'Adjuntar Foto del Usuario','accept' => 'image/png','span' => 'Foto del usuario en formato png.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $attributes = $__attributesOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__attributesOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $component = $__componentOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__componentOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(async () => {
            await buildDataTable("usuarios",
                [{
                        data: 'id',
                    },
                    {
                        data: "identificacion"
                    },
                    {
                        data: "nombres"
                    },
                    {
                        data: "aPaterno"
                    },
                    {
                        data: "aMaterno"
                    },
                    {
                        data: "telefono"
                    },
                    {
                        data: "emailUser"
                    },
                    {
                        data: "nombreFiscal"
                    },
                    {
                        data: "direccionFiscal"
                    },
                    {
                        data: "rol"
                    },
                    {
                        data: "status"
                    },
                    {
                        data: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]);
            await buildSelectForm("api/select/roles", "rolId", "Seleccione el Rol");
        });

        const crearRegistro = async (form) => {
            await buildCreateRegister("api/usuarios", form);
        };

        const editarRegistro = async (id) => {
            await buildEditRegister(id, "api/usuarios",
                [
                    "identificacion",
                    "nombres",
                    "aPaterno",
                    "aMaterno",
                    "telefono",
                    "emailUser",
                    "pswd",
                    "nombreFiscal",
                    "direccionFiscal",
                    "archivo",
                ], ["rolId"], true);
        }

        const statusRegistro = async (id) => {
            await buildStatusRegister(id, "api/usuarios");
        };

        const eliminarRegistro = async (id) => {
            await buildDeleteRegister(id, "api/usuarios");
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/cuentas/usuarios/usuarios.blade.php ENDPATH**/ ?>