<ul id="js-nav-menu" class="nav-menu">

    <?php $__currentLoopData = session('user_modules'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a title="<?php echo e($module->descripcion); ?>" data-filter-tags="<?php echo e($module->titulo); ?>">
                <i class="<?php echo e($module->icono); ?>"></i>
                <span class="nav-link-text" data-i18n="nav.theme_settings"><?php echo e($module->titulo); ?></span>
            </a>
            <ul>

                <?php $__currentLoopData = $module->subModulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li id="menu_<?php echo e($submodule->page); ?>">
                        <a href="<?php echo e($_ENV['APP_URL'] . $submodule->page); ?>" title="<?php echo e($submodule->descripcion); ?>"
                            data-filter-tags="<?php echo e($submodule->titulo); ?>">
                            <span class="nav-link-text" data-i18n="nav.theme_settings_how_it_works">
                                <?php echo e($submodule->titulo); ?>

                            </span>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
<?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/components/MenuDinamic.blade.php ENDPATH**/ ?>