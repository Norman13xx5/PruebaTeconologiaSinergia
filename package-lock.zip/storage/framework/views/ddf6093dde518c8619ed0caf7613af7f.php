<?php $__env->startSection('title', 'Categorias'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Tabla de Categorias
                    </h2>
                    <div class="panel-toolbar">
                        <button type="button" class="btn btn-info active" onclick="showModalRegistro('Categoría');">
                            Agregar <i class="fal fa-plus-square"></i>
                        </button>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.DataTable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DataTable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <th>Id</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $attributes = $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $component = $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    <?php if (isset($component)) { $__componentOriginale58da52603d8728ca37800fd8b40881d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale58da52603d8728ca37800fd8b40881d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ModalForm','data' => ['title' => 'Agregar Categoría','description' => 'Una categoría es una agrupación de un gasto.','form' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ModalForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar Categoría','description' => 'Una categoría es una agrupación de un gasto.','form' => true]); ?>
        <div class="form-row">
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '12','name' => 'description','type' => 'text','label' => 'Nombre Categoria','placeholder' => 'Ingresa nombre de categoria','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '12','name' => 'description','type' => 'text','label' => 'Nombre Categoria','placeholder' => 'Ingresa nombre de categoria','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $attributes = $__attributesOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__attributesOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $component = $__componentOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__componentOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('modals'); ?>
    <?php if (isset($component)) { $__componentOriginalec35f6959b23329aaca71618ce32bbb4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec35f6959b23329aaca71618ce32bbb4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ModalFormDetail','data' => ['modalId' => 'exampleModal2','title' => 'Agregar Categoría','description' => 'Una categoría es una agrupación de un gasto.','frmId' => 'frmRegistro2','form' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ModalFormDetail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'exampleModal2','title' => 'Agregar Categoría','description' => 'Una categoría es una agrupación de un gasto.','frmId' => 'frmRegistro2','form' => true]); ?>
        <div class="form-row">
            
            <div class="col-md-4 mb-3">
                <label class="form-label">Categoría</label>
                <select class="custom-select form-control" id="categoryId" name="categoryId">
                </select>
            </div>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '4','name' => 'description','type' => 'text','label' => 'Descripción','placeholder' => 'Ingresa descripción','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'description','type' => 'text','label' => 'Descripción','placeholder' => 'Ingresa descripción','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '4','name' => 'amount','type' => 'number','label' => 'Monto','placeholder' => 'Ingresa monto','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'amount','type' => 'number','label' => 'Monto','placeholder' => 'Ingresa monto','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec35f6959b23329aaca71618ce32bbb4)): ?>
<?php $attributes = $__attributesOriginalec35f6959b23329aaca71618ce32bbb4; ?>
<?php unset($__attributesOriginalec35f6959b23329aaca71618ce32bbb4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec35f6959b23329aaca71618ce32bbb4)): ?>
<?php $component = $__componentOriginalec35f6959b23329aaca71618ce32bbb4; ?>
<?php unset($__componentOriginalec35f6959b23329aaca71618ce32bbb4); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(async () => {
            await buildDataTable("categories",
                [{
                        data: "id"
                    },
                    {
                        data: "description"
                    },
                    {
                        data: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]);
            await buildSelectForm("api/select/category", "categoryId", "Seleccione el Categoría");
        });

        const crearRegistro = async (form) => {
            await buildCreateRegister("api/category", form);
        };

        const editarRegistro = async (id) => {
            await buildEditRegister(id, "api/category", ["description"], [], false, "ModalRegistro", "frmRegistro");
        }

        const statusRegistro = async (id) => {
            await buildStatusRegister(id, "api/category");
        };

        const eliminarRegistro = async (id) => {
            await buildDeleteRegister(id, "api/category");
        };

        const buildDataDetails = async (id) => {
            await buildDataTableDetails("gastos/" + id,
                [{
                        data: "id"
                    },
                    {
                        data: "category"
                    },
                    {
                        data: "expense"
                    },
                    {
                        data: "amount"
                    },
                    {
                        data: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]);
            $("#exampleModal").modal({
                backdrop: "static",
                keyboard: false,
            });
            $('#exampleModal').on('shown.bs.modal', function() {
                const agregarButton = $(this).find('.btn-info.active');
                agregarButton.off('click').on('click', function() {
                    showModalRegistro('Gastos', false, 'exampleModal2', 'frmRegistro2', id, 'categoryId');
                });
            });
        }

        const editarRegistroDetalle = async (id) => {
            await buildEditRegister(id, "api/gasto",
                [
                    "id",
                    "description",
                    "amount"
                ], ["categoryId"], false,
                "exampleModal2", "frmRegistro2");
        }

        const crearRegistroDetalle = async (form) => {
            await buildCreateRegister("api/gastos", form);
        };

        const statusRegistroDetalle = async (id) => {
            await buildStatusRegister(id, "api/gastos");
        };

        const eliminarRegistroDetalle = async (id) => {
            await buildDeleteRegister(id, "api/gastos");
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/cuentas/category/category.blade.php ENDPATH**/ ?>