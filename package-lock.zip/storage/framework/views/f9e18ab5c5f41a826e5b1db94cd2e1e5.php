<div class="panel-container show">
    <div class="panel-content">
        <table id="dataTableDetailLaravel" class="table table-bordered table-hover table-striped w-100">
            <thead class="bg-primary-600">
                <tr>
                    <?php echo e($slot); ?>

                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/components/DataDetailTable.blade.php ENDPATH**/ ?>