<?php $__env->startSection('title', 'Empresas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Tabla de Empresas
                    </h2>
                    <div class="panel-toolbar">
                        <button type="button" class="btn btn-info active" onclick="showModalRegistro('Empresa', true);">
                            Agregar <i class="fal fa-plus-square"></i>
                        </button>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.DataTable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DataTable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <th>Nit</th>
                    <th>Digito</th>
                    <th>Nombre</th>
                    <th>Representante</th>
                    <th>Telefono</th>
                    <th>Direccion</th>
                    <th>Correo Electronico</th>
                    <th>Pais</th>
                    <th>Ciudad</th>
                    <th>Nmro. Contacto</th>
                    <th>Correo Tecnico</th>
                    <th>Correo Logistica</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $attributes = $__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__attributesOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da)): ?>
<?php $component = $__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da; ?>
<?php unset($__componentOriginal1ae9de42ceb954f44ea3e4c8c8cdd6da); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    <?php if (isset($component)) { $__componentOriginale58da52603d8728ca37800fd8b40881d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale58da52603d8728ca37800fd8b40881d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ModalForm','data' => ['title' => 'Agregar Empresa','description' => 'Las empresas pueden ser organizaciones o personas juridicas.','form' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ModalForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar Empresa','description' => 'Las empresas pueden ser organizaciones o personas juridicas.','form' => true]); ?>
        <div class="form-row">
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'nit','type' => 'number','label' => 'NIT','placeholder' => 'Ingresa nit de la empresa','required' => true,'max' => '20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'nit','type' => 'number','label' => 'NIT','placeholder' => 'Ingresa nit de la empresa','required' => true,'max' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '2','name' => 'digito','type' => 'number','label' => 'Digito','placeholder' => 'Ingresa digito de la empresa','required' => true,'max' => '1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '2','name' => 'digito','type' => 'number','label' => 'Digito','placeholder' => 'Ingresa digito de la empresa','required' => true,'max' => '1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '4','name' => 'nombre','type' => 'text','label' => 'Nombre','placeholder' => 'Ingresa nombre de la empresa','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'nombre','type' => 'text','label' => 'Nombre','placeholder' => 'Ingresa nombre de la empresa','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '4','name' => 'representante','type' => 'text','label' => 'Representante','placeholder' => 'Representante Legal','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'representante','type' => 'text','label' => 'Representante','placeholder' => 'Representante Legal','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '4','name' => 'telefono','type' => 'number','label' => 'Numero de Telefono','placeholder' => 'Numero de contacto','required' => true,'max' => '10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'telefono','type' => 'number','label' => 'Numero de Telefono','placeholder' => 'Numero de contacto','required' => true,'max' => '10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '4','name' => 'direccion','type' => 'text','label' => 'Dirección','placeholder' => 'Dirección','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'direccion','type' => 'text','label' => 'Dirección','placeholder' => 'Dirección','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'correo','type' => 'email','label' => 'Correo Electronico','placeholder' => 'Correo Electronico de la empresa','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'correo','type' => 'email','label' => 'Correo Electronico','placeholder' => 'Correo Electronico de la empresa','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'contacto','type' => 'number','label' => 'Numero de Contacto','placeholder' => 'Numero de contacto','required' => true,'max' => '10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'contacto','type' => 'number','label' => 'Numero de Contacto','placeholder' => 'Numero de contacto','required' => true,'max' => '10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'emailTec','type' => 'email','label' => 'Correo Electronico Tecnico','placeholder' => 'Correo Electronico Tecnico','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'emailTec','type' => 'email','label' => 'Correo Electronico Tecnico','placeholder' => 'Correo Electronico Tecnico','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['col' => '6','name' => 'emailLogis','type' => 'email','label' => 'Correo Electronico Logistica','placeholder' => 'Correo Electronico Logistica','required' => true,'max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '6','name' => 'emailLogis','type' => 'email','label' => 'Correo Electronico Logistica','placeholder' => 'Correo Electronico Logistica','required' => true,'max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['file' => true,'title' => 'Logo de la empresa','label' => 'Adjuntar Logo','accept' => 'image/png','span' => 'Foto del logo de la empresa en formato png.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['file' => true,'title' => 'Logo de la empresa','label' => 'Adjuntar Logo','accept' => 'image/png','span' => 'Foto del logo de la empresa en formato png.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $attributes = $__attributesOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__attributesOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $component = $__componentOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__componentOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(async () => {
            await buildDataTable("empresas",
                [{
                        data: 'nit',
                    },
                    {
                        data: 'digito',
                    },
                    {
                        data: 'nombre',
                    },
                    {
                        data: 'representante',
                    },
                    {
                        data: 'telefono',
                    },
                    {
                        data: 'direccion',
                    },
                    {
                        data: 'correo',
                    },
                    {
                        data: 'pais',
                    },
                    {
                        data: 'ciudad',
                    },
                    {
                        data: 'contacto',
                    },
                    {
                        data: 'emailTec',
                    },
                    {
                        data: 'emailLogis',
                    },
                    {
                        data: 'status',
                    },
                    {
                        data: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]);
        });

        const crearRegistro = async (form) => {
            await buildCreateRegister("api/empresas", form);
        };

        const editarRegistro = async (nit) => {
            await buildEditRegister(nit, "api/empresas",
                [
                    "nit",
                    "digito",
                    "nombre",
                    "representante",
                    "telefono",
                    "direccion",
                    "correo",
                    "contacto",
                    "emailTec",
                    "emailLogis",
                    "archivo",
                ], true);
        }

        const statusRegistro = async (nit) => {
            await buildStatusRegister(nit, "api/empresas");
        };

        const eliminarRegistro = async (nit) => {
            await buildDeleteRegister(nit, "api/empresas");
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/cuentas/empresas/empresas.blade.php ENDPATH**/ ?>