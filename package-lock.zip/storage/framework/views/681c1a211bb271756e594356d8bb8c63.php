<div class="frame-wrap bg-white m-3">
    <div class="custom-control custom-checkbox custom-control-inline p-2">
        <h5><b>Modulo de <?php echo e($page); ?></b></h5>
    </div>
    <div class="custom-control custom-checkbox custom-control-inline m-3">
        <input type="checkbox" class="custom-control-input" id="r-<?php echo e($page); ?>"
            name="permissions[<?php echo e($page); ?>][read]">
        <label class="custom-control-label" for="r-<?php echo e($page); ?>">Leer</label>
    </div>
    <div class="custom-control custom-checkbox custom-control-inline m-3">
        <input type="checkbox" class="custom-control-input" id="w-<?php echo e($page); ?>"
            name="permissions[<?php echo e($page); ?>][write]">
        <label class="custom-control-label" for="w-<?php echo e($page); ?>">Escribir</label>
    </div>
    <div class="custom-control custom-checkbox custom-control-inline m-3">
        <input type="checkbox" class="custom-control-input" id="u-<?php echo e($page); ?>"
            name="permissions[<?php echo e($page); ?>][update]">
        <label class="custom-control-label" for="u-<?php echo e($page); ?>">Actualizar</label>
    </div>
    <div class="custom-control custom-checkbox custom-control-inline m-3">
        <input type="checkbox" class="custom-control-input" id="d-<?php echo e($page); ?>"
            name="permissions[<?php echo e($page); ?>][delete]">
        <label class="custom-control-label" for="d-<?php echo e($page); ?>">Eliminar</label>
    </div>
</div>
<?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/components/Permisos.blade.php ENDPATH**/ ?>