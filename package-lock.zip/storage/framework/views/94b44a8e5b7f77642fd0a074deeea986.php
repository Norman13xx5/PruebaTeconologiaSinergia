<?php $__env->startSection('title', 'Inicio de sesión'); ?>

<?php $__env->startSection('content'); ?>
    <form id="frmLogin">
        <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['login' => true,'name' => 'emailUser','type' => 'email','label' => 'Correo','placeholder' => 'Ingresa tu email','required' => true,'error' => 'Falta Correo Electronico.','help' => 'Escribe tu email','max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['login' => true,'name' => 'emailUser','type' => 'email','label' => 'Correo','placeholder' => 'Ingresa tu email','required' => true,'error' => 'Falta Correo Electronico.','help' => 'Escribe tu email','max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4cef534aa65f1f5c64aea755521e7239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cef534aa65f1f5c64aea755521e7239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.InputBase','data' => ['login' => true,'name' => 'pswd','type' => 'password','label' => 'Contraseña','placeholder' => 'Ingresa tu contraseña','required' => true,'error' => 'Falta contraseña.','help' => 'Escribe tu contraseña','max' => '191']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('InputBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['login' => true,'name' => 'pswd','type' => 'password','label' => 'Contraseña','placeholder' => 'Ingresa tu contraseña','required' => true,'error' => 'Falta contraseña.','help' => 'Escribe tu contraseña','max' => '191']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $attributes = $__attributesOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__attributesOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cef534aa65f1f5c64aea755521e7239)): ?>
<?php $component = $__componentOriginal4cef534aa65f1f5c64aea755521e7239; ?>
<?php unset($__componentOriginal4cef534aa65f1f5c64aea755521e7239); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale3b01cc4a59806d81a38c71fbe522604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3b01cc4a59806d81a38c71fbe522604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.BtnBase','data' => ['type' => 'login']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('BtnBase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'login']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3b01cc4a59806d81a38c71fbe522604)): ?>
<?php $attributes = $__attributesOriginale3b01cc4a59806d81a38c71fbe522604; ?>
<?php unset($__attributesOriginale3b01cc4a59806d81a38c71fbe522604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3b01cc4a59806d81a38c71fbe522604)): ?>
<?php $component = $__componentOriginale3b01cc4a59806d81a38c71fbe522604; ?>
<?php unset($__componentOriginale3b01cc4a59806d81a38c71fbe522604); ?>
<?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    <?php if (isset($component)) { $__componentOriginale58da52603d8728ca37800fd8b40881d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale58da52603d8728ca37800fd8b40881d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ModalForm','data' => ['title' => 'Registrarse','description' => 'formulario de registro de empresa']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ModalForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Registrarse','description' => 'formulario de registro de empresa']); ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body justify-content-center">
            <h1 class="text-center text-dark">
                Proximamente podras registrarte.
            </h1>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $attributes = $__attributesOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__attributesOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale58da52603d8728ca37800fd8b40881d)): ?>
<?php $component = $__componentOriginale58da52603d8728ca37800fd8b40881d; ?>
<?php unset($__componentOriginale58da52603d8728ca37800fd8b40881d); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const login = async (form) => {
            const respuestavalidacion = validarcampos("#" + form);
            if (respuestavalidacion) {
                let formData = new FormData(document.getElementById(form));
                await $.ajax({
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: formData,
                    dataType: "json",
                    url: "api/login",
                    type: "POST",
                    beforeSend: () => {
                        $('#loader-container').fadeIn('slow');
                    },
                    complete: () => {
                        $('#loader-container').fadeOut('slow');
                    },
                    success: (result) => {
                        window.location.href = "<?php echo e(route('home')); ?>";
                    },
                    error: (xhr) => {
                        Swal.fire({
                            icon: "info",
                            title: "<strong>Credenciales Incorrectas</strong>",
                            html: xhr.responseJSON.message,
                            showCloseButton: true,
                            showConfirmButton: false,
                            cancelButtonText: "Cerrar",
                            cancelButtonColor: "#dc3545",
                            showCancelButton: true,
                            backdrop: true,
                        });
                    },
                });
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brayan.martinez\Documents\FleetEase\resources\views/login/login.blade.php ENDPATH**/ ?>