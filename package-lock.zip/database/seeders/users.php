<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class users extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // User::create([
        //     'nit' => 123456789,
        //     'identificacion' => '987654321',
        //     'nombres' => 'Juan',
        //     'aPaterno' => 'Pérez',
        //     'aMaterno' => 'González',
        //     'telefono' => '123456789',
        //     'emailUser' => 'juan.perez@example.com',
        //     'pswd' => bcrypt('password123'), // Asegúrate de encriptar la contraseña
        //     'nombreFiscal' => 'Juan Pérez S.A.S.',
        //     'direccionFiscal' => 'Calle 123',
        //     'contentType' => 'application/json',
        //     'base64' => '',
        //     'rolId' => 1,
        //     'status' => 1,
        // ]);
        User::create([
            'nit' => 111111111,
            'identificacion' => '1111111111',
            'nombres' => 'admin',
            'aPaterno' => 'admin',
            'aMaterno' => 'admin',
            'telefono' => '1111111111',
            'emailUser' => 'admin@example.com',
            'pswd' => bcrypt('password123'), // Asegúrate de encriptar la contraseña
            'nombreFiscal' => 'admin S.A.S.',
            'direccionFiscal' => 'Calle 45',
            'contentType' => 'application/json',
            'base64' => '',
            'rolId' => 1,
            'status' => 1,
        ]);

        // User::create([
        //     'nit' => 222222222,
        //     'identificacion' => '2222222222',
        //     'nombres' => 'user',
        //     'aPaterno' => 'user',
        //     'aMaterno' => 'user',
        //     'telefono' => '2222222222',
        //     'emailUser' => 'user@example.com',
        //     'pswd' => bcrypt('password123'), // Asegúrate de encriptar la contraseña
        //     'nombreFiscal' => 'user S.A.S.',
        //     'direccionFiscal' => 'Calle 45',
        //     'contentType' => 'application/json',
        //     'base64' => '',
        //     'rolId' => 2,
        //     'status' => 1,
        // ]);

        User::create([
            'nit' => 1096251126,
            'identificacion' => '1096251126',
            'nombres' => 'Brayan Guillermo',
            'aPaterno' => 'Diaz',
            'aMaterno' => 'Martinez',
            'telefono' => '3182834018',
            'emailUser' => 'brahyan.com@gmail.com',
            'pswd' => bcrypt('password123'), // Asegúrate de encriptar la contraseña
            'nombreFiscal' => 'admin S.A.S.',
            'direccionFiscal' => 'Calle 45',
            'contentType' => 'application/json',
            'base64' => '',
            'rolId' => 1,
            'status' => 1,
        ]);

        // Puedes agregar más usuarios aquí
    }
}
