<div class="panel-container show">
    <div class="panel-content">
        <table id="dataTableLaravel" class="table table-bordered table-hover table-striped w-100">
            <thead class="bg-primary-600">
                <tr>
                    {{ $slot }}
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
